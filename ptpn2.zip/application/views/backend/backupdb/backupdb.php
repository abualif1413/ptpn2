<section class="py-5 slowmotion">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h6 class="text-uppercase mb-0">Back Up Database</h6>
        </div>
        <div class="card-body">
        <section>
            <div class="row mb-4">
              <div class="col-lg-12 mb-4 mb-lg-0">
              <a href="<?php echo site_url('Backupdb/DatabaseBackup')?>" type="button" class="btn btn-primary"><i class="fa fa-database" aria-hidden="true"></i> Backup Database</a>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  </div>
</section>

<script src="<?php echo base_url();?>assets/backend/js/jquery-3.3.1.js"></script>