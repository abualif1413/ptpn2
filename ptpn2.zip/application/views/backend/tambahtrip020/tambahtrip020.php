<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/themes/mint-choc/jquery-ui.css" rel="stylesheet" />
<style type="text/css">
    #panel_input tr:nth-child(odd) {
        background-color: #F9F9F9;
    }
</style>
<section class="py-5 slowmotion">
    <div class="row">
        <div class="col-md-12">
        <div class="card">
            <div class="card-header">
            <h6 class="text-uppercase mb-0">
                <label class="pull-right">Data Trip Temporary</label>
            </h6>
            </div>
            <div class="card-body">
                <form method="get" action="">
                    <div class="row">
                        <div class="col-sm-2">Tanggal</div>
                        <div class="col-sm-3">
                            <input type="text" name="tanggal" id="tanggal" class="form-control" value="<?php echo $tanggal; ?>" />
                        </div>
                        <div class="col-sm-2">
                            <button class="btn btn-primary" type="submit" name="tampilkan_data">Tampilkan Data</button>
                        </div>
                    </div>
                </form>
                <hr />
                <?php
                    if($tanggal != "") {
                ?>
                        <h5>Data trip untuk tanggal <?php echo $tanggal; ?></h5>
                        <button class="btn btn-primary" type="button" onclick="document.location.href='<?php echo site_url('TambahTrip020Insert'); ?>?tanggal=<?php echo $tanggal; ?>'">Tambah Data</button>
                        <br /><br />
                        <table class="table">
                            <thead>
                                <tr>
                                    <th width="30px">No.</th>
                                    <th>No. SPTBS</th>
                                    <th>No. Polisi</th>
                                    <th>Blok</th>
                                    <th>Restan Awal</th>
                                    <th>Jmlh janjang</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $no = 0;
                                foreach($dataTampil as $dt) {
                            ?>
                                    <tr>
                                        <td><?php echo ++$no; ?></td>
                                        <td><?php echo $dt["sptbs"]; ?></td>
                                        <td><?php echo $dt["nomor_polisi_trek"]; ?></td>
                                        <td><?php echo $dt["blok"]; ?></td>
                                        <td><?php echo $dt["jumlah_restan"]; ?></td>
                                        <td><?php echo $dt["jumlah_janjang"]; ?></td>
                                    </tr>
                            <?php
                                }
                            ?>
                            </tbody>
                        </table>
                <?php
                    }
                ?>
            </div>
        </div>
        </div>
    </div>
</section>
<script src="<?php echo base_url();?>assets/backend/js/jquery-3.3.1.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script type="text/javascript">
    $('#tanggal').datepicker({
        defaultDate: "+1d",
        dateFormat: 'yy-mm-dd',
        showOtherMonths: false,
        changeMonth: false,
        selectOtherMonths: false,
        required: true,
        showOn: "focus",
        numberOfMonths: 1
    });
</script>