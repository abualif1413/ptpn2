<!DOCTYPE html>
<html>
<head>
    <title><?php echo $title; ?></title>
    <link href="https://fonts.googleapis.com/css?family=Noto+Serif&display=swap" rel="stylesheet"> 
    <style type="text/css">
        body {
            background: url("<?php echo base_url();?>assets/backend/img/bg-monitoring.jpg");
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center; 
            background-size: cover;
            margin: 0px;
            font-family: 'Noto Serif', serif;
        }
        .judul {
            font-weight: bold;
            font-size: 25pt;
            margin-bottom: 30px;
            border: solid 1px #CCC;
            width: 95%;
            padding: 20px;
            background-color: #132C4282;
            color: white;
            box-shadow: #b5b5e1 5px 5px 3px;
            border-radius: 5px;
        }

        .panel_blok {
            float: left;
            margin-right: 20px;
            margin-bottom: 20px;
            border: solid 1px #CCC;
            width: 250px;
            padding: 20px;
            background-color: #132C4282;
            color: white;
            box-shadow: #b5b5e1 5px 5px 3px;
            border-radius: 5px;
        }

        .panel_blok .blok {
            font-weight: bold;
            font-size: 18pt;
            margin: 0px;
        }
    </style>
    <script src="<?php echo base_url();?>assets/backend/js/jquery-3.3.1.js"></script>
    <script type="text/javascript">
        function putar_data() {
            $(".panel_blok").each(function() {
                var blok = $(this).attr("blok");
                $("#target_" + blok).html("Target panen (Kg) : ...");
                $("#realisasi_tbs_kg_" + blok).html("Hasil TBS (Kg) : ...");
                $("#realisasi_tbs_persen_" + blok).html("Hasil TBS (%) : ...");
                $("#realisasi_brondolan_kg_" + blok).html("Hasil Brondolan (Kg) : ...");
                $("#realisasi_brondolan_persen_" + blok).html("Hasil Brondolan (%) : ...");
                $.ajax({
                    type        : 'POST',
                    url         : '<?php echo base_url()?>SlideShowMonitoringPanen/get_data',
                    data        : "bulan=<?php echo $bulan; ?>&tahun=<?php echo $tahun; ?>&id_afdeling=<?php echo $afdeling; ?>&blok=" + blok,
                    async       : true,
                    dataType    : 'json',
                    success : function(data){
                        $("#target_" + blok).html("Target panen (Kg) : " + data.target_sd_hari_ini);
                        $("#realisasi_tbs_kg_" + blok).html("Hasil TBS (Kg) : " + data.hasil_tbs_kg);
                        $("#realisasi_tbs_persen_" + blok).html("Hasil TBS (%) : " + data.hasil_tbs_persen);
                        $("#realisasi_brondolan_kg_" + blok).html("Hasil Brondolan (Kg) : " + data.hasil_brondolan_kg);
                        $("#realisasi_brondolan_persen_" + blok).html("Hasil Brondolan (Kg) : " + data.hasil_brondolan_persen);
                    }
                });
            })
        }

        
        $(function() {
            putar_data();
            setInterval(putar_data, 10000);
        });
    </script>
</head>
<body>
<div style="width: 100%; height: 100%; position: fixed; background-color: #6e5edb45; overflow: auto;">
<div class="judul">
    Monitoring hasil panen
    <table cellspacing="0" cellpadding="2" style="font-size: 50% !important;">
        <tr>
            <td>Nama Kebun</td>
            <td>:</td>
            <td><?php echo $nama_kebun; ?></td>
        </tr>
        <tr>
            <td>Afdeling</td>
            <td>:</td>
            <td><?php echo $nama_afdeling; ?></td>
        </tr>
        <tr>
            <td>Per Tanggal</td>
            <td>:</td>
            <td><?php echo $per_tgl_tostring; ?></td>
        </tr>
    </table>
</div>
<?php
    foreach($blok as $blk) {
        echo "<div class='panel_blok' blok='" . $blk["blok"] . "'>";
            echo "<div class='blok'>Blok : " . $blk["blok"] . "</div>";
            echo "<div class='tahun_tanam'>Tahun tanam : " . $blk["tahun_tanam"] . "</div>";
            echo "<div class='target' id='target_" . $blk["blok"] . "'>Target panen : </div>";
            echo "<div class='tbs_kg' id='realisasi_tbs_kg_" . $blk["blok"] . "'>Hasil TBS (Kg) : </div>";
            echo "<div class='tbs_persen' id='realisasi_tbs_persen_" . $blk["blok"] . "'>Hasil TBS (%) : </div>";
            echo "<div class='brondolan_kg' id='realisasi_brondolan_kg_" . $blk["blok"] . "'>Hasil Brondolan (Kg) : </div>";
            echo "<div class='brondolan_persen' id='realisasi_brondolan_persen_" . $blk["blok"] . "'>Hasil Brondolan (%) : </div>";
        echo "</div>";
    }
?>
</div>
</body>
</html>
