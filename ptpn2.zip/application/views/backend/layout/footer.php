<footer class="footer bg-white shadow align-self-end py-3 px-xl-5 w-100">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6 text-center text-md-left text-primary">
        <p class="mb-2 mb-md-0">Your company &copy; 2018-2020</p>
      </div>
      <div class="col-md-6 text-center text-md-right text-gray-400">
        <p class="mb-0">Design by <a href="https://bootstrapious.com/admin-templates" class="external text-gray-400">Bootstrapious</a></p>
        <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
      </div>
    </div>
  </div>
</footer>