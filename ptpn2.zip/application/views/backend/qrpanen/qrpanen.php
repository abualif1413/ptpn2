<section class="py-5 slowmotion">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h6 class="text-uppercase mb-0">
                <label class="pull-right">Qr Panen</label>
            </h6>
          </div>
          <div class="card-body">
            <iframe  style="border:none;" src="https://ptpn2.asikinonlineaja.com/qrcode/" height="500" width="100%"></iframe>
          </div>
        </div>
      </div>
    </div>
  </section>