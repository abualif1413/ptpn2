<?php
define('GUSER', 'officialimam03@gmail.com'); // email address
define('GPWD', 'sayangmamak'); // email password
define('HOST', 'smtp.gmail.com'); // email server host
define('PORT',465 ); // email server port
?>