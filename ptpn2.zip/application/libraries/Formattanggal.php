<?php
class Formattanggal {

    function __construct() {
        include_once APPPATH . '/third_party/FormatTanggal.php';
    }
}
?>
