<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SlideShowMonitoringPanen extends MY_Controller {

	public function __construct(){
        parent::__construct();
		
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        
	}
	
	public function index()
	{
        if ($this->session->userdata('email')) {
            $this->load->database();

            // Mencari nama kebun dan afdeling
            $ds_kbn_afd = $this->db->query("
                SELECT
                    kbn.nama_kebun, afd.nama_afdeling
                FROM
                    tbl_afdeling afd
                    LEFT JOIN tbl_kebun kbn ON afd.id_kebun = kbn.id
                WHERE
                    afd.id = '" . $this->input->get("afdeling") . "'
            ");
            $nama_kebun = "";
            $nama_afdeling = "";
            foreach($ds_kbn_afd->result() as $kbnafd) {
                $nama_kebun = $kbnafd->nama_kebun;
                $nama_afdeling = $kbnafd->nama_afdeling;
            }

            // Mencari sampai tanggal berapa slide show ditampilkan
            $ds_per_tgl = $this->db->query("
                SELECT
                    per_tgl.per_tgl, DATE_FORMAT(per_tgl.per_tgl,'%d-%m-%Y') AS sampai_tgl
                FROM
                    (
                        SELECT
                        CASE
                            WHEN LAST_DAY('" . $this->input->get("tahun") . "-" . $this->input->get("bulan") . "-01') > CURDATE() THEN CURDATE()
                            ELSE LAST_DAY('" . $this->input->get("tahun") . "-" . $this->input->get("bulan") . "-01')
                        END AS per_tgl
                    ) per_tgl
            ");
            $per_tgl = "";
            $per_tgl_tostring = "";
            foreach($ds_per_tgl->result() as $tgl) {
                $per_tgl = $tgl->per_tgl;
                $per_tgl_tostring = $tgl->sampai_tgl;
            }

            // Mencari semua blok pada afdeling yang dipilih
            $blok = array();
            $ds_blok = $this->db->query("
                SELECT
                    MAX(blk.id) AS id, blk.blok, MAX(blk.tahun_tanam) AS tahun_tanam
                FROM
                    tbl_blok blk
                WHERE
                    blk.id_afdeling = '" . $this->input->get("afdeling") . "'
                GROUP BY
                    blk.blok
                ORDER BY
                    blk.blok ASC
            ");
            foreach($ds_blok->result() as $blk) {
                $temp_blok = array(
                    "id" => $blk->id,
                    "blok" => $blk->blok,
                    "tahun_tanam" => $blk->tahun_tanam
                );
                array_push($blok, $temp_blok);
            }

            $data['title']  		    = 'Monitoring hasil panen';
            $data['bulan']              = $this->input->get("bulan");
            $data['tahun']              = $this->input->get("tahun");
            $data['afdeling']           = $this->input->get("afdeling");
            $data['per_tgl']            = $per_tgl;
            $data['per_tgl_tostring']   = $per_tgl_tostring;
            $data['blok']               = $blok;
            $data['nama_kebun']         = $nama_kebun;
            $data['nama_afdeling']      = $nama_afdeling;
            $this->db->close();
			$this->load->view('backend/slideshowmonitoringpanen/slideshowmonitoringpanen',$data);
        }else{
            redirect('Authadmin');
        }
		
    }
    
    function get_data() {
        // Mencari target panen
        $this->load->database();
        $target_panen = "";
        $ds_target_panen = $this->db->query("
            SELECT
                MAX(blk.id) AS id, blk.blok, MAX(blk.tahun_tanam) AS tahun_tanam,
                MAX(COALESCE(target.target_panen, 0)) AS target_panen
            FROM
                tbl_blok blk
                LEFT JOIN tbl_target_panen_bulanan target ON blk.id = target.id_blok AND bulan = '" . $this->input->post("bulan") . "'
                AND tahun = '" . $this->input->post("tahun") . "'
            WHERE
                blk.id_afdeling = '" . $this->input->post("id_afdeling") . "' AND blk.blok = '" . $this->input->post("blok") . "'
            GROUP BY
                blk.blok
            ORDER BY
                blk.blok ASC
        ");
        foreach($ds_target_panen->result() as $target) {
            $target_panen = $target->target_panen;
        }

        // Mencari sampai tanggal berapa slide show ditampilkan
        $ds_per_tgl = $this->db->query("
            SELECT
                per_tgl.per_tgl, DATE_FORMAT(per_tgl.per_tgl,'%d-%m-%Y') AS sampai_tgl,
                DATE_FORMAT(per_tgl.per_tgl,'%d') AS jumlah_hari, DATE_FORMAT(per_tgl.total_hari,'%d') AS total_hari
            FROM
                (
                    SELECT
                        CASE
                            WHEN LAST_DAY('" . $this->input->post("tahun") . "-" . $this->input->post("bulan") . "-01') > CURDATE() THEN CURDATE()
                            ELSE LAST_DAY('" . $this->input->post("tahun") . "-" . $this->input->post("bulan") . "-01')
                        END AS per_tgl,
                        LAST_DAY('" . $this->input->post("tahun") . "-" . $this->input->post("bulan") . "-01') AS total_hari
                ) per_tgl
        ");
        $dari_tgl = $this->input->post("tahun") . "-" . $this->input->post("bulan") . "-01";
        $per_tgl = "";
        $jumlah_hari = 0;
        $total_hari = 0;
        foreach($ds_per_tgl->result() as $tgl) {
            $per_tgl = $tgl->per_tgl;
            $jumlah_hari = $tgl->jumlah_hari;
            $total_hari = $tgl->total_hari;
        }

        // Mencari realisasi panen
        $realisasi_tbs = 0;
        $realisasi_brondolan = 0;
        $ds_realisasi_panen = $this->db->query("
            SELECT
                sptbs.id, sptbs.id_blok_no_1, blok.blok,
                sptbs.berat_no_1 AS berat_tbs, sptbs.berondolan_timbang_1 AS berat_brondolan
            FROM
                tbl_sptbs_setelah_slip_timbang sptbs
                LEFT JOIN tbl_blok blok ON sptbs.id_blok_no_1 = blok.id
            WHERE
                sptbs.tanggal BETWEEN '" . $dari_tgl . "' AND '" . $per_tgl . "'
                AND blok.id_afdeling = '" . $this->input->post("id_afdeling") . "' AND blok.blok = '" . $this->input->post("blok") . "'
            
            UNION ALL
            
            SELECT
                sptbs.id, sptbs.id_blok_no_2, blok.blok,
                sptbs.berat_no_2, sptbs.berondolan_timbang_2
            FROM
                tbl_sptbs_setelah_slip_timbang sptbs
                LEFT JOIN tbl_blok blok ON sptbs.id_blok_no_2 = blok.id
            WHERE
                sptbs.tanggal BETWEEN '" . $dari_tgl . "' AND '" . $per_tgl . "'
                AND blok.id_afdeling = '" . $this->input->post("id_afdeling") . "' AND blok.blok = '" . $this->input->post("blok") . "'
            
            UNION ALL
            
            SELECT
                sptbs.id, sptbs.id_blok_no_3, blok.blok,
                sptbs.berat_no_3, sptbs.berondolan_timbang_3
            FROM
                tbl_sptbs_setelah_slip_timbang sptbs
                LEFT JOIN tbl_blok blok ON sptbs.id_blok_no_3 = blok.id
            WHERE
                sptbs.tanggal BETWEEN '" . $dari_tgl . "' AND '" . $per_tgl . "'
                AND blok.id_afdeling = '" . $this->input->post("id_afdeling") . "' AND blok.blok = '" . $this->input->post("blok") . "'
        ");
        foreach($ds_realisasi_panen->result() as $realisasi) {
            $realisasi_tbs += $realisasi->berat_tbs;
            $realisasi_brondolan += $realisasi->berat_brondolan;
        }

        $this->db->close();

        $result_data = array();
        if($target_panen == 0) {
            $result_data = array(
                "target_panen" => "N/A",
                "target_sd_hari_ini" => "N/A",
                "hasil_tbs_kg" => "N/A",
                "hasil_tbs_persen" => "N/A",
                "hasil_brondolan_kg" => "N/A",
                "hasil_brondolan_persen" => "N/A"
            );
        } else {
            $target_sd_hari_ini = ($target_panen / $total_hari) * $jumlah_hari;
            $persen_tbs = ($realisasi_tbs * 100) / $target_sd_hari_ini;
            $persen_brondolan = ($realisasi_tbs == 0) ? 0 : (($realisasi_brondolan * 100) / $realisasi_tbs);
            $result_data = array(
                "target_panen" => number_format($target_panen, 2),
                "target_sd_hari_ini" => number_format($target_sd_hari_ini, 2),
                "hasil_tbs_kg" => number_format($realisasi_tbs, 2),
                "hasil_tbs_persen" => number_format($persen_tbs, 2),
                "hasil_brondolan_kg" => number_format($realisasi_brondolan, 2),
                "hasil_brondolan_persen" => number_format($persen_brondolan, 2)
            );
        }
        

        self::json($result_data);
    }
    
}
