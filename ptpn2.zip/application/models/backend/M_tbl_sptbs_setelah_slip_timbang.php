<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_tbl_sptbs_setelah_slip_timbang extends MY_Model{

	public function __construct(){
		parent::__construct('tbl_sptbs_setelah_slip_timbang');
	}

}
