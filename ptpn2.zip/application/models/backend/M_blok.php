<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_blok extends MY_Model{

	public function __construct(){
		parent::__construct('tbl_blok');
	}

}
